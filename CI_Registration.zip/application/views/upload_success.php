<!DOCTYPE html>
<html>
 
   <head> 
      <title>Upload Success Form</title> 
   </head>
	
   <body>  
      <h3>Your file was successfully uploaded in the folder!</h3>
      <?php
        if(isset($message)){
            echo $message."<br>";
        }
    ?>

   <!-- <?php
      print_r($upload_data);
      ?> -->
   <?php echo $upload_data['full_path']?>
     <img src="<?php echo $upload_data['full_path']?>" height="250px" width="250px">
		

      <!-- <ul> 
         <?php foreach ($upload_data as $item => $value): ?>
         <li> <?php echo $item;?>: <?php echo $value;?></li> 
          
         <?php endforeach; ?>
      </ul>   -->
		
	  <p><?php 
	      $link=base_url().'uploads/'.$upload_data['file_name'];
	      
	       echo anchor($link,'Click to See The Image!');
	      ?></p>

      <p><?php echo anchor('Upload', 'Upload Another File!'); ?></p>
   </body>
	
</html>